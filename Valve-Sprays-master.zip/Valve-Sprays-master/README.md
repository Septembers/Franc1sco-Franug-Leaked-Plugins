Commands:
```
!sprays - put your spray
!sprays - select your spray
```


## Follow the rules here: https://github.com/Franc1sco/Franug-PRIVATE-PLUGINS
## Dont forget to give me +rep in my steam profile ( http://steamcommunity.com/id/franug ) if you like my plugins :)