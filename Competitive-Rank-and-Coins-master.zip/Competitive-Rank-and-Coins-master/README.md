Admin commands
```
sm_elorank <#userid|name> <0-18>
sm_emblem <#userid|name> <874-6011>
sm_prorank <#userid|name> <0-40>
```
User commands
```
sm_coin
sm_mm
sm_profile
```