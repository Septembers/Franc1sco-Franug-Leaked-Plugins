## Description:

-Root users dont have blocked the plugin lists.

-Include a translation file for edit the message.

-Include a log in addons/sourcemod/logs when somebody try to see the plugin list.


## Cvars (put in server.cfg):
```
sm_plugins_block_ban "-1" // Ban player? -1 = no ban, 0 = permanent, other value is ban time
```


## Requeriments:

Dhooks version -> https://forums.alliedmods.net/showthread.php?t=180114

ptah version (csgo only) -> https://forums.alliedmods.net/showthread.php?p=2463410