##### Cvars (put in server.cfg)
```
sm_stattrak_viponly "0" // Set only for VIPs
sm_stattrak_vipflags "t" // Set only for VIPs
``````


##### Database setup example (in addons/sourcemod/configs/databases.cfg) also this plugin support MySQL too.
```
	"stattrak"
	{
		"driver"			"sqlite"
		"database"			"stattrak"
	}
```


## Follow the rules here: https://github.com/Franc1sco/Franug-PRIVATE-PLUGINS
## Dont forget to give me +rep in my steam profile ( http://steamcommunity.com/id/franug ) if you like my plugins :)