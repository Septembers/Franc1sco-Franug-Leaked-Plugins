##### Cvars (put in server.cfg)
```
sm_nametag_viponly "0" // Set only for VIPs
sm_nametag_vipflags "t" // Set only for VIPs
``````


##### Database setup example (in addons/sourcemod/configs/databases.cfg) also this plugin support MySQL too.
```
	"nametag"
	{
		"driver"			"sqlite"
		"database"			"nametag"
	}
```


## Follow the rules here: https://github.com/Franc1sco/Franug-PRIVATE-PLUGINS
## Dont forget to give me +rep in my steam profile ( http://steamcommunity.com/id/franug ) if you like my plugins :)