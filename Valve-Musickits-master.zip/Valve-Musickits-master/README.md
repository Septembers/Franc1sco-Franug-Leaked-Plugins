## Command:
```
!music - open the main menu
```

# Requeriment:

SteamWorks - https://forums.alliedmods.net/showthread.php?t=229556

csgoitems - https://www.dropbox.com/s/sb0wks2g0nqkn7z/newcsgoitems.zip?dl=0

Go to file addons/sourcemod/configs/core.cfg and set "SlowScriptTimeout" to "0"