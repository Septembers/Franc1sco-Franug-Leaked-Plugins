## Commands for open the main menu:
```
sm_glove
sm_gloves
sm_arm
sm_arms
sm_manusa
sm_manusi
```

## Cvars
Configure the cvars in cfg/sourcemod/csgo_gloves.cfg (autocreated file when you load the plugin)
```
// Close menu after selection
// -
// Default: "0"
// Minimum: "0.000000"
// Maximum: "1.000000"
sm_csgogloves_closemenu "0"

// Enable thirdperson view for gloves
// -
// Default: "1"
// Minimum: "0.000000"
// Maximum: "1.000000"
sm_csgogloves_thirdperson "1"

// Set gloves only for VIPs
// -
// Default: "t"
sm_csgogloves_vipflags "t"

// Set gloves only for VIPs
// -
// Default: "0"
// Minimum: "0.000000"
// Maximum: "1.000000"
sm_csgogloves_viponly "0"

// Enable fixes for cksurf plugin
// -
// Default: "0"
// Minimum: "0.000000"
// Maximum: "1.000000"
sm_csgogloves_cksurffix "0"

// Enable delay after spawn.
// -
// Default: "0"
// Minimum: "0.000000"
// Maximum: "1.000000"
sm_csgogloves_delaySpawn "0"
```

## Note: if you want to use custom gloves too, you need to buy the working custom gloves plugin compatible with this plugin from me (Franc1sco Franug).

## Follow the rules here: https://github.com/Franc1sco/Franug-PRIVATE-PLUGINS
## Dont forget to give me +rep in my steam profile ( http://steamcommunity.com/id/franug ) if you like my plugins :)