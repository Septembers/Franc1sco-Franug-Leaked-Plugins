# Required: https://www.dropbox.com/s/pd1vhxq5ip26x5u/Custom-Chat-Colors-CSGO%20and%20scp.zip?dl=0


# Commands
```
sm_colors - change chat color
sm_tagcolors - change tag color
```